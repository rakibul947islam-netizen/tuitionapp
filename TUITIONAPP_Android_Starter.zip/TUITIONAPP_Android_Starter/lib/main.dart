import 'package:flutter/material.dart';

void main() => runApp(const TuitionApp());

class TuitionApp extends StatelessWidget {
  const TuitionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'TUITIONAPP',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF4F8FC)),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  bool bengali = true;
  @override
  Widget build(BuildContext context) {
    final labels = bengali ? ['হোম', 'শিক্ষার্থী', 'ফি', 'উপস্থিতি', 'পরীক্ষা'] : ['Home', 'Students', 'Fees', 'Attendance', 'Tests'];
    final pages = const [DashboardPage(), SimplePage(title: 'Students', subtitle: 'Manage student records'), SimplePage(title: 'Fees', subtitle: 'Track fees and payments'), SimplePage(title: 'Attendance', subtitle: 'Record daily attendance'), SimplePage(title: 'Tests', subtitle: 'Manage tests and results')];
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.white, title: const Text('TUITIONAPP', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1769AA))), actions: [TextButton(onPressed: () => setState(() => bengali = !bengali), child: Text(bengali ? 'বাংলা' : 'English')), const SizedBox(width: 8)]),
      body: pages[selected],
      bottomNavigationBar: NavigationBar(selectedIndex: selected, onDestinationSelected: (i) => setState(() => selected = i), destinations: [
        NavigationDestination(icon: const Icon(Icons.home_outlined), label: labels[0]),
        NavigationDestination(icon: const Icon(Icons.people_outline), label: labels[1]),
        NavigationDestination(icon: const Icon(Icons.payments_outlined), label: labels[2]),
        NavigationDestination(icon: const Icon(Icons.fact_check_outlined), label: labels[3]),
        NavigationDestination(icon: const Icon(Icons.quiz_outlined), label: labels[4]),
      ]),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF1769AA), borderRadius: BorderRadius.circular(18)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Welcome to TUITIONAPP', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('Your tuition centre, organised.', style: TextStyle(color: Colors.white70))])),
    const SizedBox(height: 18),
    const Wrap(spacing: 12, runSpacing: 12, children: [StatCard(title: 'Students', value: '0', icon: Icons.people), StatCard(title: 'Teachers', value: '0', icon: Icons.school), StatCard(title: 'Fees Due', value: '₹0', icon: Icons.currency_rupee), StatCard(title: 'Present Today', value: '0', icon: Icons.fact_check)]),
    const SizedBox(height: 22), const Text('Quick overview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    const Card(child: ListTile(leading: Icon(Icons.info_outline, color: Color(0xFF1769AA)), title: Text('Starter version'), subtitle: Text('This is a UI prototype. Sign-in, cloud database and payments are not connected yet.'))),
  ]);
}

class StatCard extends StatelessWidget {
  final String title, value; final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(width: (MediaQuery.of(context).size.width - 44) / 2, child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF1769AA)), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(color: Colors.black54))]))));
}

class SimplePage extends StatelessWidget {
  final String title, subtitle;
  const SimplePage({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(child: Card(margin: const EdgeInsets.all(24), child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.construction, size: 42, color: Color(0xFF1769AA)), const SizedBox(height: 12), Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(subtitle), const SizedBox(height: 8), const Text('Feature screen placeholder')]))));
}
