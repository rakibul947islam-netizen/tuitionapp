# TUITIONAPP — Android Starter

Flutter starter UI for the Android-only TUITIONAPP project.

## Included in this starter
- Blue-and-white app branding
- Bengali/English toggle for navigation labels
- Dashboard prototype
- Placeholder screens for Students, Fees, Attendance and Tests

## Important limitation
This is a **UI-only starter**, not a finished app and not an APK. Authentication, multi-centre data isolation, Firebase/Firestore, notifications, UPI payments, PDF receipts, WhatsApp integration, parent portal and real data operations are not connected yet.

## Planned app structure
- Roles: Super Admin, Centre Owner, Teacher and Parent
- Each tuition centre must have separate accounts and data
- Planned collections: Centres, Users, Students, Teachers, Batches, Fees, Attendance, Tests, Enquiries and Payments
- Centre-ID-based access control and tested Firestore security rules are required before storing real user data

## Build on a computer with Flutter installed
1. Install Flutter SDK and Android Studio.
2. Open this folder in an IDE.
3. Run `flutter pub get`.
4. Run `flutter run` to test.
5. Run `flutter build apk --release` to build the APK.
6. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

Uploading this ZIP to GitHub alone does not create an APK. A configured Flutter build environment or cloud build workflow is needed.
